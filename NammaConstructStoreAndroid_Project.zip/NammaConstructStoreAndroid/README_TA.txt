NAMMA CONSTRUCT STORE - ANDROID APP PROJECT

இந்த project உங்கள் Netlify website-ஐ Android App (WebView) ஆக திறக்கும்.
Website: https://candid-entremet-f73107.netlify.app/

APK உருவாக்க 2 வழிகள்:

வழி 1 - Android Studio (கணினி தேவை)
1. Android Studio நிறுவவும்.
2. ZIP-ஐ Extract செய்து NammaConstructStoreAndroid folder-ஐ Android Studio-ல் Open செய்யவும்.
3. Gradle Sync முடிந்ததும் Build > Build Bundle(s) / APK(s) > Build APK(s) தேர்வு செய்யவும்.
4. app/build/outputs/apk/debug/app-debug.apk என்ற இடத்தில் APK கிடைக்கும்.

வழி 2 - GitHub Actions (Android Studio install செய்ய வேண்டியதில்லை)
1. ZIP-ஐ Extract செய்யவும்.
2. GitHub-ல் புதிய repository உருவாக்கி இந்த folder-ல் உள்ள files அனைத்தையும் upload செய்யவும்.
3. GitHub repository-ல் Actions tab திறக்கவும்.
4. 'Build Android APK' workflow-ஐ தேர்வு செய்து Run workflow அழுத்தவும்.
5. Build முடிந்ததும் workflow run-இன் Artifacts பகுதியில் 'Namma-Construct-Store-APK' ZIP-ஐ download செய்யவும்.
6. அந்த ZIP-ஐ extract செய்து app-debug.apk-ஐ உங்கள் Android phone-ல் install செய்யவும்.

குறிப்பு:
- இங்கு Android SDK/Gradle build environment இல்லாததால் APK binary-ஐ நேரடியாக compile செய்ய முடியவில்லை.
- இது install செய்யத் தயாரான APK அல்ல; APK உருவாக்கும் Android project.
- Website திறக்க இணைய இணைப்பு தேவை.
- App பெயர்: Namma Construct Store
- Package ID: com.nammaconstructstore.app
